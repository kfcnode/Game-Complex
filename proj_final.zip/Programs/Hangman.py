import random

class Hangman() :
    
    def __init__(self):
        self.word_list= [
    'wares', 'somount', 'extend', 'brown', 'expert', 'tired', 'humidity', 'backpack', 'crust', 'dent', 'market',
    'knock', 'smite', 'windy', 'coin', 'throw', 'silence', 'bluff', 'downfall', 'climb', 'lying', 'weaver',
    'snob', 'kickoff', 'match', 'quaker', 'foreman', 'excite', 'thinking', 'mend', 'allergen', 'pruning', 'coat',
    'emerald', 'coherent', 'manic', 'multiple', 'square', 'funded', 'funnel', 'sailing', 'dream', 'mutation', 'strict',
    'mystic', 'film', 'guide', 'strain', 'bishop', 'settle', 'plateau', 'emigrate', 'marching', 'optimal', 'medley',
    'endanger', 'wick', 'condone', 'schema', 'rage', 'figure', 'plague', 'aloof', 'there', 'reusable', 'refinery',
    'suffer', 'affirm', 'captive', 'flipping', 'prolong', 'main', 'coral', 'dinner', 'rabbit', 'chill', 'seed',
    'born', 'shampoo', 'italian', 'giggle', 'roost', 'palm', 'globe', 'wise', 'grandson', 'running', 'sunlight',
    'spending', 'crunch', 'tangle', 'forego', 'tailor', 'divinity', 'probe', 'bearded', 'premium', 'featured',
    'serve', 'borrower', 'examine', 'legal', 'outlive', 'unnamed', 'unending', 'snow', 'whisper', 'bundle', 'bracket',
    'deny', 'blurred', 'pentagon', 'reformed', 'polarity', 'jumping', 'gain', 'laundry', 'hobble', 'culture', 'whittle',
    'docket', 'mayhem', 'build', 'peel', 'board', 'keen', 'glorious', 'singular', 'cavalry', 'present', 'cold',
    'hook', 'salted', 'just', 'dumpling', 'glimmer', 'drowning', 'admiral', 'sketch', 'subject', 'upright', 'sunshine',
    'slide', 'calamity', 'gurney', 'adult', 'adore', 'weld', 'masking', 'print', 'wishful', 'foyer', 'tofu', 'machete',
    'diced', 'behemoth', 'rout', 'midwife', 'neglect', 'mass', 'game', 'stocking', 'folly', 'action', 'bubbling',
    'scented', 'sprinter', 'bingo', 'egyptian', 'comedy', 'rung', 'outdated', 'radical', 'escalate', 'mutter',
    'desert', 'memento', 'kayak', 'talon', 'portion', 'affirm', 'dashing', 'fare', 'battle', 'pupil', 'rite', 'smash',
    'true', 'entrance', 'counting', 'peruse', 'dioxide', 'hermit', 'carving', 'backyard', 'homeless', 'medley',
    'packet', 'tickle', 'coming', 'leave', 'swing', 'thicket', 'reserve', 'murder', 'costly', 'corduroy', 'bump',
    'oncology', 'swatch', 'rundown', 'steal', 'teller', 'cable', 'oily', 'official', 'abyss', 'schism', 'failing',
    'guru', 'trim', 'alfalfa', 'doubt', 'booming', 'bruised', 'playful', 'kicker', 'jockey', 'handmade', 'landfall',
    'rhythm', 'keep', 'reassure', 'garland', 'sauna', 'idiom', 'fluent', 'lope', 'gland', 'amend', 'fashion', 'treaty',
    'standing', 'current', 'sharpen', 'cinder', 'idealist', 'festive', 'frame', 'molten', 'sill', 'glisten',
    'fearful', 'basement', 'minutia', 'coin', 'stick', 'featured', 'soot', 'static', 'crazed', 'upset', 'robotics',
    'Gay Yash', 'dwarf', 'shield', 'butler', 'stitch', 'stub', 'sabotage', 'parlor', 'prompt', 'heady', 'horn',
    'bygone', 'rework', 'painful', 'composer', 'glance', 'acquit', 'eagle', 'solvent', 'backbone', 'smart', 'atlas',
    'leap', 'danger', 'bruise', 'seminar', 'tinge', 'trip', 'narrow', 'while', 'jaguar', 'seminary', 'command',
    'cassette', 'draw', 'anchovy', 'scream', 'blush', 'organic', 'applause', 'parallel', 'trolley', 'pathos', 'origin',
    'hang', 'pungent', 'angular', 'stubble', 'painted', 'forward', 'saddle', 'muddy', 'orchid', 'prudence', 'disprove',
    'yiddish', 'lobbying', 'neuron', 'tumor', 'haitian', 'swift', 'mantel', 'wardrobe', 'consist', 'storied', 'extreme',
    'payback', 'control', 'dummy', 'influx', 'realtor', 'detach', 'flake', 'consign', 'adjunct', 'stylized', 'weep',
    'prepare', 'pioneer', 'tail', 'platoon', 'exercise', 'dummy', 'clap', 'actor', 'spark', 'dope', 'phrase', 'welsh',
    'wall', 'whine', 'fickle', 'wrong', 'stamina', 'dazed', 'cramp', 'filet', 'foresee', 'seller', 'award', 'mare',
    'uncover', 'drowning', 'ease', 'buttery', 'luxury', 'bigotry', 'muddy', 'photon', 'snow', 'oppress', 'blessed',
    'call', 'stain', 'amber', 'rental', 'nominee', 'township', 'adhesive', 'lengthy', 'swarm', 'court', 'baguette',
    'leper', 'vital', 'push', 'digger', 'setback', 'accused', 'taker', 'genie', 'reverse', 'fake', 'widowed', 'renewed',
    'goodness', 'featured', 'curse', 'shocked', 'shove', 'marked', 'interact', 'mane', 'hawk', 'kidnap', 'noble',
    'proton', 'effort', 'patriot', 'showcase', 'parish', 'mosaic', 'coil', 'aide', 'breeder', 'concoct', 'pathway',
    'hearing', 'bayou', 'regimen', 'drain', 'bereft', 'matte', 'bill', 'medal', 'prickly', 'sarcasm', 'stuffy',
    'allege', 'monopoly', 'lighter', 'repair', 'worship', 'vent', 'hybrid', 'buffet', 'lively']
        
        

        self.word = random.choice(self.word_list).upper()
        self.word_completion = "_"*len(self.word)
        self.guessed = False
        self.guessed_letters = []
        self.guessed_words = []
        self.tries = 6
        print("Let's play Hangman!")
        self.stage = self.display_hangman(self.tries)            
                
    def guess(self, guess):
        if len(guess) == 1 and guess.isalpha():
            if guess not in self.word and guess not in self.guessed_letters and not self.guessed:
                self.tries -= 1
                self.guessed_letters.append(guess)
                self.guessedstat=-1
            elif guess in self.guessed_letters:
                self.guessedstat=0
            else:
                self.guessed_letters.append(guess)
                word_as_list = list(self.word_completion)
                indices = [i for i, letter in enumerate(self.word) if letter == guess]
                for index in indices:
                    word_as_list[index] = guess
                self.word_completion = "".join(word_as_list)
                self.guessedstat=-1
                if "_" not in self.word_completion:
                    self.guessed = True
        elif guess.isalpha() and not self.guessed:
            if guess in self.guessed_words:
                self.guessedstat=0
            elif guess != self.word:
                self.guessedstat=1
                self.tries -= 1
                self.guessed_words.append(guess)
            else:
                self.guessed = True
                self.word_completion = self.word
        else:
            self.guessedstat=2
        
        return(self.guessed, self.stage, self.word_completion, self.guessedstat)


    def display_hangman(self, tries):
        stages = [  # final state: head, torso, both arms, and both legs
                        """
                        __ __
                        |      |
                        |      O
                        |     \\|/
                        |      |
                        |     / \\
                        -----
                        """,
                        # head, torso, both arms, and one leg
                        """
                        __ __
                        |      |
                        |      O
                        |     \\|/
                        |      |
                        |     / 
                        -----
                        """,
                        # head, torso, and both arms
                        """
                        __ __
                        |      |
                        |      O
                        |     \\|/
                        |      |
                        |      
                        -----
                        """,
                        # head, torso, and one arm
                        """
                        __ __
                        |      |
                        |      O
                        |     \\|
                        |      |
                        |     
                        -----
                        """,
                        # head and torso
                        """
                        __ __
                        |      |
                        |      O
                        |      |
                        |      |
                        |     
                        -----
                        """,
                        # head
                        """
                        __ __
                        |      |
                        |      O
                        |    
                        |      
                        |     
                        -----
                        """,
                        # initial empty state
                        """
                        __ __ 
                        |      |
                        |      
                        |    
                        |      
                        |     
                        -----
                        """
            ]
        return stages[tries]

